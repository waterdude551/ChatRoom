let bed, bookshelf, desk, room_outline;
let sprite;
let spriteImg;
let door;
let escapeDoor;
let speed = 3;
let roomFont;
let glow;

let hoveredObject = null;
let popUpText = "";

let yesButton;
let noButton;
let logOnButton;
let cancelLogOnButton;
let buttonsShown = false;

//for typewriter effect
let typeTextShown = "";
let typeIndex = 0;
let typeCounter = 0;
let typeSpeed = 3;

//bounds for object hitboxes

let bedMinX = 570, bedMaxX = 950, bedMinY = 65, bedMaxY = 320

let bookshelfMinX = 400, bookshelfMaxX = 970, bookshelfMinY = 510, bookshelfMaxY = 750

let deskMinX = 70, deskMaxX = 330, deskMinY = 90, deskMaxY = 370

let canSleep = false; // can only sleep after chatting is done for the day
let canChat = true; // only false if you have to sleep
let chatsCanSleep = 2; // if it's a currentChat in here, then you're supposed to sleep before the numbered chat. i just realized it's only chat 2. u only sleep once

let justHidButtons = false;
let leftButtonX = 340;
let buttonY = 670;
let rightButtonX = 600;

let sleeping = false;
let sleepingProgress = 0.0; // to 1.0
let sleepingDuration = 3.0;


//few chats -> bed then new day with more chatting
//if user tries to sleep before chats are done show dialogue that reminds to keep chatting
//can sleep turns true after chats are complete for that day 

function loadRoom(){
    // loadImage('images/room_assets/door.png');

    spriteImg = loadImage('images/room_assets/sprite.png');
    spritesheet = loadImage('images/room_assets/spritesheet.png');
    roombg = loadImage('images/room_assets/newroombg.png');
    roomFont = loadFont('assets/fonts/UbuntuMono-Regular.ttf');
    sprite = new Sprite(400,400); //SPRITE PRE LOADS HERE!
    glow = loadImage('images/room_assets/pcglow.png');
   
    cursorImg = loadImage('images/LMB.png');
    loadRoomButtons();
}

function loadRoomButtons() {

    yesButton = createButton("> Sleep");
    yesButton.style("font-family", "Ubuntu Mono");
    yesButton.style("background-color", color(255,255,255));
    yesButton.style("font-weight", "bold");
    yesButton.style("font-size", "20px");
    noButton = createButton("> Look around");
    noButton.style("font-family", "Ubuntu Mono");
    noButton.style("background-color", color(255,255,255));
    noButton.style("font-weight", "bold");
    noButton.style("font-size", "20px");

    
    yesButton.position(leftButtonX, buttonY);
    noButton.position(rightButtonX, buttonY);

    yesButton.mousePressed(() => {

        if(canSleep){
            sleeping = true;
            clearOldPopUp();
            popUpText = "> You had a good night's sleep";
            hideButtons();
        }
        else {
            clearOldPopUp();
            popUpText = "> You still have chats to finish.";
            hideButtons();
        }
    });

    noButton.mousePressed(() => {
        popUpText = "";
        hideButtons();
    });

    yesButton.hide();
    noButton.hide();

    // more buttonsss
    logOnButton = createButton("> Log on");
    cancelLogOnButton = createButton("> Cancel");

    //no more boring html button
    logOnButton.style("font-family", "Ubuntu Mono"); 
    logOnButton.style("background-color", color(255,255,255));
    logOnButton.style("font-weight", "bold");
    logOnButton.style("font-size", "20px");
    cancelLogOnButton.style("font-family", "Ubuntu Mono");
    cancelLogOnButton.style("font-weight", "bold");
    cancelLogOnButton.style("background-color", color(255,255,255))
    cancelLogOnButton.style("font-size", "20px");

    
    logOnButton.position(leftButtonX, buttonY);
    cancelLogOnButton.position(rightButtonX, buttonY);

    logOnButton.mousePressed(() => {
        hideButtons();
        if (canChat) {
            goToChat();
        } else {
            clearOldPopUp();
            popUpText = "> No more chats for today.";
        }
    });

    cancelLogOnButton.mousePressed(() => {
        popUpText = "";
        hideButtons();
    });

    logOnButton.hide();
    cancelLogOnButton.hide();
}

function drawRoom(){
    
    background(255);
    
 
   
    image(roombg,0,0)
    
    if (popUpText == "") { 
        sprite.move(); // only allow movement outside text
    } else {
        sprite.currFrame = 1;
    }
    
    sprite.display();
    image(glow,0,0);

    
    if (sleeping) {
        if (sleepingProgress >= 2) {
            print("done sleeping")
            sleeping = false
            sleepDone();
            sleepingProgress = 0;
        }
        let fadeAlpha;
        if (sleepingProgress < 1) {
            fadeAlpha = lerp(0,255,sleepingProgress);
        } else {
            fadeAlpha = lerp(0,255,1-(sleepingProgress-1));
        }
        fill(0, 0, 0, fadeAlpha);
        rect(0,0,width,height);
        sleepingProgress += 1/60 / sleepingDuration;
        return;
    }

    drawMouseIfHover();
    
    hoveredObject = getHoveredObject();
    // text step
    if (popUpText != "") { //if not null show popup
        fill(WHITE);
        rect(220, 540, 600, 180);
        // type effect
        if (typeIndex < popUpText.length) {
            typeCounter++;

            if (typeCounter % typeSpeed === 0) {
                typeTextShown += popUpText[typeIndex];
                typeIndex++;
            }
        }
        // button show
        // hardcode :(
        if (hoveredObject === "bed" 
            && typeIndex >= popUpText.length 
            && !buttonsShown 
            && popUpText != "> You still have chats to finish."
            && canSleep) {
            showBedButtons();
        }
        if (hoveredObject === "desk" 
            && typeIndex >= popUpText.length 
            && !buttonsShown 
            && popUpText != "> No more chats for today." 
            && canChat) {
            showDeskButtons();
        }
        fill(BLACK);
        textSize(30);
        textFont(roomFont);
        text(typeTextShown, 235, 575, 570);
    }

    if (justHidButtons) {
        justHidButtons = false;
    }
}

let SPRITE_FRAMES_PER_FRAME = 20;
class Sprite { 
    constructor(x,y) {
        this.x = x;
        this.y = y;
        this.framesUntilAnim = SPRITE_FRAMES_PER_FRAME;
        this.currFrame = 1;
        this.direction = 0; // 0123 = down, left, right, up
        this.moving = false;
        this.img = spriteImg;
    }

    move(){
        this.moving = false;

        if(keyIsDown(65)) {
            if(this.x > 0) {
            this.x -= speed 
            this.direction = 1
            this.moving = true;
            }
        }
        if(keyIsDown(68)) {
            if(this.x < width - spriteImg.width) {
            this.x += speed
            this.direction = 2
            this.moving = true;
            }
        }
        if(keyIsDown(87)) {  
            if(this.y > 0){
            this.y -= speed
            this.direction = 3
            this.moving = true;
            }
        }
        if(keyIsDown(83)) { 
            if(this.y < height - spriteImg.height) {
            this.y += speed
            this.direction = 0
            this.moving = true;
            }
        }
        
        if (this.moving) {
            this.animate();
        } else {
            this.currFrame = 1;
            this.framesUntilAnim = 0;
        }
    }

    animate() {
        this.framesUntilAnim--;
        if (this.framesUntilAnim <= 0) {
            this.currFrame = (this.currFrame + 1) % 3
            this.framesUntilAnim = SPRITE_FRAMES_PER_FRAME;
        }
    }

    display(){
        image(spritesheet, this.x, this.y, 108, 192, this.currFrame * 108, this.direction * 192, 108, 192);
    }
}



function inRange(value, min, max) {
    if(value+108 >= min && value <= max) {
        return true;
    }
    return false;
}


function roomMousePressed() {
    // When click
    if (justHidButtons) {
        // don't do anything if you just came out of buttons
        return;
    }
    if(popUpText != "") {
        // if a box is already up
        if (buttonsShown) {
            return; // delegate to buttons
        }
        if (popUpText == typeTextShown) {
            // and it's done, remove the box
            print("hiding popup");
            typeTextShown = "";
            typeIndex = 0;
            typeCounter = 0;
            popUpText = "";
            return;
        } else {
            // and it's still typing, finish it
            typeTextShown = popUpText;
            typeIndex = popUpText.length;
            return;
        }
    }
    hoveredObject = getHoveredObject();
    switch (hoveredObject) {
        case ("bookshelf"):
            popUpText = getPopUpText();
            typeTextShown = "";
            typeIndex = 0;
            typeCounter = 0;
            break;
        case ("bed"):
            if (canSleep) {
                popUpText = "> It's your bed. Go to sleep?";
            } else {
                popUpText = getPopUpText();
            }
            typeTextShown = "";
            typeIndex = 0;
            typeCounter = 0;
            hideButtons();
            break;
        case ("desk"):
            if (!canChat) {
                popUpText = "> No messages right now.";
            } else {
                popUpText = getPopUpText();
            }
            typeTextShown = "";
            typeIndex = 0;
            typeCounter = 0;
            break;
        default:
            typeTextShown = "";
            typeIndex = 0;
            typeCounter = 0;
            popUpText = ""; //close popup
    }
}


function getHoveredObject() {//store what uur in range of
    if (
        inRange(sprite.x, bookshelfMinX, bookshelfMaxX) &&
        inRange(sprite.y, bookshelfMinY, bookshelfMaxY)
    ) {
        return "bookshelf";
    }

    if (
        inRange(sprite.x, bedMinX, bedMaxX) &&
        inRange(sprite.y, bedMinY, bedMaxY)
    ) {
        return "bed";
    }

    if (
        inRange(sprite.x, deskMinX, deskMaxX) &&
        inRange(sprite.y, deskMinY, deskMaxY)
    ) {
        return "desk";
    }
    return null;
}

function drawMouseIfHover(){
    if (hoveredObject) {
        // print("drawing mouse");
        image(cursorImg, sprite.x, sprite.y, 30, 41);
    }
}
    
function showDeskButtons() {
    logOnButton.show();
    cancelLogOnButton.show();
    buttonsShown = true;
}

function showBedButtons() {
    yesButton.show();
    noButton.show();
    buttonsShown = true;
}

function hideButtons() {
    yesButton.hide();
    noButton.hide();
    logOnButton.hide();
    cancelLogOnButton.hide();
    buttonsShown = false;
    justHidButtons = true;
}


function clearOldPopUp() {
    popUpText = "";
    typeTextShown = "";
    typeIndex = 0;
    typeCounter = 0;
}

function sleepDone() {
    canSleep = false;
    sleeping = false;
    canChat = true;
}